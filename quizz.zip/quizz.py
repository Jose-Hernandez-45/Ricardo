import random

class Quiz:
    def __init__(self, tema, preguntas):
        self.tema = tema
        self.preguntas = preguntas
        self.puntuacion = 0

    def iniciar(self):
        print(f"\nIniciando el quiz de {self.tema}.\n")
        random.shuffle(self.preguntas)
        
        for pregunta, opciones, respuesta in self.preguntas[:10]:
            print(pregunta)
            for i, opcion in enumerate(opciones, 1):
                print(f"{i}. {opcion}")
            try:
                eleccion = int(input("Elige la opción correcta (1-4): ")) - 1
                if opciones[eleccion] == respuesta:
                    print("¡Correcto!\n")
                    self.puntuacion += 1
                else:
                    print(f"Incorrecto. La respuesta correcta era: {respuesta}\n")
            except (IndexError, ValueError):
                print("Opción no válida. Pasamos a la siguiente pregunta.\n")
        
        self.mostrar_resultado()

    def mostrar_resultado(self):
        print(f"\nHas terminado el quiz de {self.tema}.")
        print(f"Obtuviste {self.puntuacion} respuestas correctas de 10.")
        
        if self.puntuacion >= 8:
            print("¡Eres un experto en el tema!\n")
        elif 4 <= self.puntuacion <= 7:
            print("Te falta ver algunas películas del tema.\n")
        else:
            print("Parece que no sabes mucho sobre este tema.\n")

# Preguntas de ejemplo para cada tema
preguntas_terror = [
    ("¿En qué año se estrenó 'El Exorcista'?", ["1973", "1980", "1995", "2001"], "1973"),
    ("¿Quién dirigió 'Psicosis'?", ["Alfred Hitchcock", "Steven Spielberg", "James Wan", "John Carpenter"], "Alfred Hitchcock"),
    ("¿En qué película aparece el personaje Freddy Krueger?", ["Pesadilla en Elm Street", "Halloween", "Viernes 13", "Scream"], "Pesadilla en Elm Street"),
    ("¿Cuál es el nombre de la muñeca poseída en 'El Conjuro'?", ["Annabelle", "Chucky", "Samara", "Tiffany"], "Annabelle"),
    ("¿En qué año se estrenó la primera película de 'Halloween'?", ["1978", "1984", "1990", "2000"], "1978"),
    ("¿Qué actor interpretó a Drácula en la película clásica de 1931?", ["Bela Lugosi", "Lon Chaney", "Christopher Lee", "Boris Karloff"], "Bela Lugosi"),
    ("¿En qué película aparece el Hotel Overlook?", ["El Resplandor", "El Aro", "Actividad Paranormal", "Insidious"], "El Resplandor"),
    ("¿Qué película presenta una familia que adopta a una niña que resulta ser un adulto?", ["La Huérfana", "Hereditary", "La Monja", "El Conjuro"], "La Huérfana"),
    ("¿Cuál es el nombre del payaso en 'Eso'?", ["Pennywise", "Bozo", "Krusty", "Joker"], "Pennywise"),
    ("¿Qué director es conocido por la saga de 'Evil Dead'?", ["Sam Raimi", "James Wan", "George Romero", "John Carpenter"], "Sam Raimi")

]

preguntas_accion = [
    ("¿Quién protagonizó 'Duro de Matar'?", ["Bruce Willis", "Sylvester Stallone", "Arnold Schwarzenegger", "Tom Cruise"], "Bruce Willis"),
    ("¿Qué película popularizó la frase 'Hasta la vista, baby'?", ["Terminator 2", "Rambo", "Predator", "Rocky"], "Terminator 2"),
    ("¿En qué película de acción aparece el personaje John Wick?", ["John Wick", "Matrix", "Speed", "Con Air"], "John Wick"),
    ("¿Quién interpretó a Neo en 'Matrix'?", ["Keanu Reeves", "Tom Cruise", "Nicolas Cage", "Will Smith"], "Keanu Reeves"),
    ("¿Cuál de estas películas es conocida por la frase 'Yippee ki-yay'?", ["Duro de Matar", "Rambo", "Terminator", "Misión Imposible"], "Duro de Matar"),
    ("¿Qué director es conocido por su trabajo en la saga 'Mad Max'?", ["George Miller", "James Cameron", "Steven Spielberg", "Michael Bay"], "George Miller"),
    ("¿Cuál es el nombre del personaje de Arnold Schwarzenegger en 'Comando'?", ["John Matrix", "John Wick", "James Bond", "Rocky Balboa"], "John Matrix"),
    ("¿En qué película de acción los personajes buscan el 'Santo Grial'?", ["Indiana Jones y la Última Cruzada", "La Roca", "Los Cazafantasmas", "Arma Mortal"], "Indiana Jones y la Última Cruzada"),
    ("¿Quién protagoniza 'Misión Imposible' como Ethan Hunt?", ["Tom Cruise", "Brad Pitt", "Bruce Willis", "Matt Damon"], "Tom Cruise"),
    ("¿En qué película Mel Gibson interpreta a William Wallace?", ["Corazón Valiente", "Gladiador", "Troya", "300"], "Corazón Valiente"),
]

preguntas_ciencia_ficcion = [
    ("¿En qué película se utiliza la frase 'Que la fuerza te acompañe'?", ["Star Wars", "Star Trek", "Alien", "Matrix"], "Star Wars"),
    ("¿Quién dirigió 'Blade Runner'?", ["Ridley Scott", "George Lucas", "Stanley Kubrick", "James Cameron"], "Ridley Scott"),
    ("¿Cuál es el nombre de la nave en 'Alien'?", ["Nostromo", "Enterprise", "Millennium Falcon", "Discovery One"], "Nostromo"),
    ("¿Quién dirigió 'Interestelar'?", ["Christopher Nolan", "Steven Spielberg", "James Cameron", "Ridley Scott"], "Christopher Nolan"),
    ("¿En qué año se estrenó 'Matrix'?", ["1999", "2001", "1995", "2003"], "1999"),
    ("¿Qué actor interpretó al androide en 'Blade Runner'?", ["Rutger Hauer", "Harrison Ford", "Edward James Olmos", "Sean Young"], "Rutger Hauer"),
    ("¿Qué película de ciencia ficción popularizó la frase 'E.T. teléfono mi casa'?", ["E.T.", "Encuentros Cercanos del Tercer Tipo", "Alien", "El Quinto Elemento"], "E.T."),
    ("¿En qué película aparece la inteligencia artificial HAL 9000?", ["2001: Odisea en el Espacio", "Blade Runner", "Tron", "Inteligencia Artificial"], "2001: Odisea en el Espacio"),
    ("¿Cuál es el planeta natal de los Na'vi en 'Avatar'?", ["Pandora", "Krypton", "Arrakis", "Gallifrey"], "Pandora"),
    ("¿Qué película de ciencia ficción fue dirigida por James Cameron en 1984 y protagonizada por Arnold Schwarzenegger?", ["Terminator", "Depredador", "Abyss", "Aliens"], "Terminator"),
]

preguntas_comedia = [
    ("¿Cuál es la película de comedia protagonizada por Jim Carrey en la que no puede mentir?", ["Mentiroso Mentiroso", "Ace Ventura", "El Show de Truman", "La Máscara"], "Mentiroso Mentiroso"),
    ("¿Qué actor protagonizó 'Un detective suelto en Hollywood'?", ["Eddie Murphy", "Chris Rock", "Will Smith", "Martin Lawrence"], "Eddie Murphy"),
    ("¿Quién protagonizó 'La Máscara'?", ["Jim Carrey", "Eddie Murphy", "Adam Sandler", "Will Ferrell"], "Jim Carrey"),
    ("¿Cuál es el nombre del personaje interpretado por Mike Myers en 'Austin Powers'?", ["Austin Powers", "Dr. Malito", "Felicity Shagwell", "Nigel Powers"], "Austin Powers"),
    ("¿Qué actor interpretó a 'Ace Ventura'?", ["Jim Carrey", "Ben Stiller", "Adam Sandler", "Will Smith"], "Jim Carrey"),
    ("¿Cuál es la película en la que los hermanos Farrelly dirigen a un personaje llamado Harry Dunne?", ["Tonto y Retonto", "Zoolander", "Tropic Thunder", "El Reportero"], "Tonto y Retonto"),
    ("¿En qué película Bill Murray vive el mismo día una y otra vez?", ["El Día de la Marmota", "Atrapado en el Tiempo", "Al Filo del Mañana", "Click"], "El Día de la Marmota"),
    ("¿Qué actor protagonizó 'Un detective suelto en Hollywood'?", ["Eddie Murphy", "Chris Rock", "Will Smith", "Martin Lawrence"], "Eddie Murphy"),
    ("¿Qué película cómica presenta la icónica frase '¿Hablas conmigo?'?", ["Taxi Driver", "Zoolander", "Scarface", "Mi Pobre Angelito"], "Zoolander"),
    ("¿En qué película se forma una banda con los personajes Jake y Elwood Blues?", ["The Blues Brothers", "Wayne's World", "Rock of Ages", "School of Rock"], "The Blues Brothers")
]

# Creación de los quizzes
quiz_terror = Quiz("Terror", preguntas_terror)
quiz_accion = Quiz("Acción", preguntas_accion)
quiz_ciencia_ficcion = Quiz("Ciencia Ficción", preguntas_ciencia_ficcion)
quiz_comedia = Quiz("Comedia", preguntas_comedia)

# Menú para seleccionar el tema del quiz
def menu():
    while True:
        print("\nBienvenido al Quiz de Películas")
        print("Selecciona un tema:")
        print("1. Terror")
        print("2. Acción")
        print("3. Ciencia Ficción")
        print("4. Comedia")
        print("5. Salir")
        
        eleccion = input("Ingresa el número de tu elección: ")
        
        if eleccion == "1":
            quiz_terror.iniciar()
        elif eleccion == "2":
            quiz_accion.iniciar()
        elif eleccion == "3":
            quiz_ciencia_ficcion.iniciar()
        elif eleccion == "4":
            quiz_comedia.iniciar()
        elif eleccion == "5":
            print("¡Gracias por jugar! Hasta la próxima.")
            break
        else:
            print("Opción no válida. Intenta de nuevo.")

# Iniciar el menú del quiz
menu()
