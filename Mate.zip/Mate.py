import matplotlib.pyplot as plt
import numpy as np

# Definir la potencia de x y el número a sumar
n1 = int(input('Escribe el número que quieres sumar: '))

# Función a realizar
print(f'Tu función es f(x) = X^2 + {n1}')

# Definir la función que queremos integrar
def f(x):
    return x**2 + n1  # Puedes cambiar esta función por otra que desees

# Función para calcular la suma de Riemann y devolver los puntos de los subintervalos
def suma_riemann(a, b, n):
    delta_x = (b - a) / n  # Tamaño del intervalo
    area_total = 0
    x_values = []  # Almacena los puntos de evaluación de los subintervalos
    y_values = []  # Almacena los valores de f(x) en esos puntos
    
    # Iteramos sobre los subintervalos y calculamos la suma de Riemann
    for i in range(n):
        x = a + i * delta_x  # Punto de evaluación (inicio del subintervalo)
        area_total += f(x) * delta_x  # Añadir área del rectángulo (f(x) * delta_x)
        x_values.append(x)  # Guardar el valor de x
        y_values.append(f(x))  # Guardar el valor de f(x) en x
    
    return area_total, x_values, y_values

# Definir los intervalos
i1 = int(input('Escribe el primer intervalo: '))
i2 = int(input('Escribe el segundo intervalo: '))

# Validar el número de iteraciones (subintervalos)
n = int(input('Escribe el número de iteraciones: '))

# Validación corregida para n > 0
while n <= 0:
    print("Error... Coloca un número mayor a 0")
    n = int(input("Introduce un número de iteraciones: "))

# Calcular el área bajo la curva y obtener los puntos de evaluación
area_1, x_vals, y_vals = suma_riemann(i1, i2, n)

# Mostrar los resultados
print(f"Área bajo la curva entre a={i1} y b={i2}: {area_1}")

# Graficar la función y el área bajo la curva
x = np.linspace(i1 - 1, i2 + 1, 1000)  # Valores de x para graficar
y = f(x)

# Crear la gráfica de la función
plt.plot(x, y, label=f'Función $f(x) = x^2 + {n1}$')

# Graficar el área bajo la curva
plt.fill_between(x, y, where=[i1 <= val <= i2 for val in x], color='orange', alpha=0.5, label="Área bajo la curva")

# Dibujar las líneas de las iteraciones (límites de los subintervalos) en color rojo
for i in range(len(x_vals)):
    plt.axvline(x=x_vals[i], color='red', linestyle='--', alpha=0.7)  # Línea vertical en cada punto de evaluación
    plt.plot([x_vals[i], x_vals[i]], [0, y_vals[i]], color='red', lw=1.5)  # Línea roja que forma los lados del rectángulo

# Dibujar una línea roja conectando las partes superiores de los rectángulos (donde tocan la función)
plt.plot(x_vals, y_vals, color='red', linestyle='-', lw=1.5, label="Iteraciones")

# Configuración de la gráfica
plt.axhline(0, color='black', linewidth=0.5)
plt.axvline(0, color='black', linewidth=0.5)
plt.title(f"Área bajo la curva entre [{i1}, {i2}] con {n} iteraciones")
plt.xlabel('x')
plt.ylabel('f(x)')
plt.legend()
plt.grid(True)

# Mostrar la gráfica
plt.show()
