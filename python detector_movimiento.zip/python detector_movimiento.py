import cv2
import numpy as np

# Inicializa la captura de video
cap = cv2.VideoCapture(0)  # 0 para la cámara predeterminada

# Lee el primer cuadro para inicializar
ret, frame1 = cap.read()
ret, frame2 = cap.read()

while cap.isOpened():
    # Calcula la diferencia entre los dos cuadros
    diff = cv2.absdiff(frame1, frame2)
    # Convierte a escala de grises
    gray = cv2.cvtColor(diff, cv2.COLOR_BGR2GRAY)
    # Aplica un desenfoque para reducir el ruido
    gray = cv2.GaussianBlur(gray, (5, 5), 0)

    # Umbraliza la imagen para obtener las áreas de movimiento
    _, thresh = cv2.threshold(gray, 20, 255, cv2.THRESH_BINARY)

    # Encuentra los contornos de las áreas de movimiento
    contours, _ = cv2.findContours(thresh, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    for contour in contours:
        if cv2.contourArea(contour) > 500:  # Ajusta este valor según tus necesidades
            (x, y, w, h) = cv2.boundingRect(contour)
            cv2.rectangle(frame1, (x, y), (x + w, y + h), (0, 255, 0), 2)

    # Muestra el cuadro original y el cuadro de diferencia
    cv2.imshow("Detector de Movimiento", frame1)
    cv2.imshow("Diferencia", thresh)

    # Actualiza los cuadros para la siguiente iteración
    frame1 = frame2
    ret, frame2 = cap.read()

    if cv2.waitKey(1) == 27:  # Presiona 'Esc' para salir
        break

# Libera la captura y cierra las ventanas
cap.release()
cv2.destroyAllWindows()
